Modular Attachments Server Side Slider/Shooter System
v3.2.0

3.2.0 - New actual mongoIDs this time. Fix for stock tube positionals
3.1.0 - Swap to mongoIDs
3.0.1 - Fix for bad filters on optics mount
3.0.0 - Added new attachments from 14.0 to filters
2.1.1 - Added new attachments from 13.5 to filters
2.1.0 - Blacklist Test
2.0.0 - combines all of my attachment adjustments into a single mod.

This mod wouldn't be possible without Mighty_Condor's code as the framework.


Installation:
First install my custom shop module
https://hub.sp-tarkov.com/files/file/1208-mfac-shop-module/

Extract with 7zip (https://www.7-zip.org/)

Extract folder in 7z file to your mods folder
The directory should look like this:
/user/mods/aaMFACSHOP/


/user/mods/Gear_MGS_Collection​/




Known Issues:
Don't know? Maybe some server botgen issues perhaps?

Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.


LICENSES:
Backend/mod.ts by Might Condor - University of Illinois/NCSA Open Source License

Bundles/models by PETTAN - Creative Commons BY-NC-ND 4.0


安装
1. 前安装我的 MFACSHOP ( https://sns.oddba.cn/97049.html )
2. 把 zip档案打开后放进你的user/mods/文件夹。
        /user/mods/xMASS system/
去除之前把所有mod加入的物品消除。

移动系统位置移动座M已经加入黑名单，bots应该不可使用。
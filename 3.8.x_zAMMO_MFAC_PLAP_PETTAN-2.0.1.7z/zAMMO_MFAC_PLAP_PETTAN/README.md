PLAP Ammo
v2.0.0

Adds 3 7.62 polymer hybrid rounds to ALICE

This mod wouldn't be possible without Mighty_Condor's code as the framework.


Installation:
First install my custom shop module
https://hub.sp-tarkov.com/files/file/1208-mfac-shop-module/

Extract with 7zip (https://www.7-zip.org/)

Extract folder in 7z file to your mods folder

The directory should look like this:

/user/mods/aaMFACSHOP/


/user/mods/zAMMO_MFAC_PLAP_PETTAN​/



Known Issues:
???

Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.


LICENSES:
Backend/mod.ts by Might Condor - University of Illinois/NCSA Open Source License

Bundles/models by PETTAN - Creative Commons BY-NC-ND 4.0
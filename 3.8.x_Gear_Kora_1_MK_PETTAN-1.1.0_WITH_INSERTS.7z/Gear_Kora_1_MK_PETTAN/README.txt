Gear_Kora_1_MK_PETTAN
v1.0.0

Adds to Alice LL4
NPP KIASS Kora-1-MK armored rig (Kollontay)
PSh-88 DJETA assault helmet

INCOMPATIBILITIES

"SPT-Realism" added to incompatibilities in package.json, you may remove the parameter to make it work with "SPT-Realism" BUT do not post "SPT-Realism" related support questions here.

Installation:

Extract with 7zip (https://www.7-zip.org/)
Extract folder in 7z file to your mods folder

The directory should look like this:
/user/mods/aaMFACSHOP/
/user/mods/Armor_Inserts_MFAC_PETTAN/
/user/mods/Gear_Kora_1_MK_PETTAN/

Known Issues:
  ???

Uninstalling:
If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.

Licenses
Modified and rigged by PETTAN - CC BY NC ND 4.0

Models from BSG - Owners something something rights

Backend/mod.ts by Mighty_Condor - University of Illinois/NCSA Open Source License




安装步骤:

首先，去下载我的商人MOD和MFAC插板MOD (已经在.7z 里)

https://hub.sp-tarkov.com/files/file/1824-mfac-armor-inserts/
https://sns.oddba.cn/97049.html

使用7zip解压缩 (https://www.7-zip.org/)

把7z压缩包解压到你的模组文件夹中去



你的mods文件夹应包含以下MOD:

/user/mods/aaMFACSHOP/
/user/mods/Armor_Inserts_MFAC_PETTAN/
/user/mods/Gear_Kora_1_MK_PETTAN/


不兼容性

"SPT-Realism" 在package.json添加了不兼容mod, 你可以移除那条参数来强制使用 "SPT-Realism" 但是别问我任何与 "SPT-Realism" 相关的问题


已知问题:

商人那里服饰的预览图标有时候会显示不正常.
移动系统位置移动座M已经加入黑名单，bots应该不可使用。


卸载:

如果你想移除该MOD，在删除MOD前请确保你的存档里不包含任何属于该MOD的物品.
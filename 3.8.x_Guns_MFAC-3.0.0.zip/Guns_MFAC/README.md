M Guns
v2.0.2

Adds a few guns to the game.

MFAC PAN-94 5.45x39 assault rifle/MFAC PAN-95 5.56x45 assault rifle
  2 AK type rifles that has a 2 round burst (1800 RPM) feature/
MFAC PAEK-971 5.45x39 assault rifle 
  5.45 AK with a high rof fire (900RPM).
Weapon mastery is shared with the AK74 series.

MFAC PSTM-9 9x19 carbine
 STM-9 with full auto(800 RPM) function
Weapon mastery is shared with STM-9.

MFAC PM1911A1 .45 ACP pistol
 M1911A1 with full auto/burst(850 RPM) function
Weapon mastery is shared with M1911A1.

MFAC PGlock 17 9x19 pistol
 Glock 17 with full auto/burst(750 RPM) function
Weapon mastery is shared with Glocks.

MFAC POP-SKS 7.62x39 carbine
 OP-SKS with full auto(750 RPM) function
Weapon mastery is shared with SKS.

MFAC PM14 7.62x51 rifle
 M1A with full auto(650 RPM) function
Weapon mastery is shared with M1A.

MFAC PSVDS 7.62x54R sniper rifle
 SVD with full auto(650 RPM) function
Weapon mastery is shared with SVD.

MFAC PSTM-7TT 7.62x25 TT carbine 
 STM-9 with full auto(800 RPM) function
Weapon mastery is shared with STM-9.

MFAC PPB 9x18PM silenced pistol
 PB pistol with full auto(1100 RPM) function
Weapon mastery is shared with PB.

MFAC PPM (t) 9x18PM pistol
 PM pistol with full auto(1100 RPM) function
Weapon mastery is shared with PM.

MFAC PMP5V 9x18PM submachine gun
 MP5 chambered in 9x18PM (780RPM)
Weapon mastery is shared with MP5.

MFAC PM4C545 5.45x39 assault rifle
 M4 chambered in 5.45x39 (800RPM)
Weapon mastery is shared with M4.

MFAC PFN 4-6 4.6x30 pistol
 FN57 chambered in 4.6HK
Weapon mastery is shared with FN57.

MFAC PRD-762R 762x54R assault rifle
 RD704 chambered in 762x54R
Weapon mastery is shared with AK74.

MFAC PSaiga 12ga automatic shotgun
 Full auto Saiga 12 (450RPM)
Weapon mastery is shared with Saiga12.

MFAC PVPO-209 .366 TKM carbine
 Full auto VPO-209 (800RPM)
Weapon mastery is shared with AKM.

MFAC PGlock 7.62TT machine pistol
 Full auto Glock chambered in 7.62TT (750RPM)
Weapon mastery is shared with Glocks.

MFAC PMk939 Mutant 9x39mm assault rifle
  9x39 assault rifle (650RPM)
Weapon mastery is shared with Mk47.

MFAC PMP-43 12ga sawed-off double-barrel shotgun
  Shotgun that goes in secondary slot, can fire 12.7x108
Weapon mastery shared with MP-43

MFAC PPKM308 7.62x51 machine gun
  7.62x51 beltfed LMG (780 RPM)
Weapon mastery shared with PKM

MFAC PPKM12g 12g machine gun
  12g beltfed LMG (780 RPM)
Weapon mastery shared with PKM


Accesories
MFAC SVDS 7.62x54R 22 inch heavy barrel
MFAC SVD 75 round magazine
MFAC M14 7.62x51 22 inch heavy barrel
MFAC M14 7.62x51 16 inch heavy barrel
MFAC Glock multicaliber 50-round magazine
MFAC HK MP5VSD upper receiver
MFAC PMP5V 9x18PM 50-round drum magazine
MFAC multicaliber Magpul PMAG 30 GEN M3 W STANAG 30-round magazine
MFAC multicaliber Magpul PMAG D-60 STANAG 60-round magazine
MFAC PFN 4-6 46x30 20-round magazine
MFAC PSOK-12ga 20-round compact magazine
MFAC Glock 7.62TT 33 round magazine
MFAC Glock 7.62TT 17 round magazine
MFAC PX 9x39 50-round drum magazine
MFAC PPKM 658mm heavy barrel
MFAC PPKM308 200-round box magazine
MFAC PPKM12g 100-round box magazine


This mod wouldn't be possible without Mighty_Condor's code as the framework.

Installation:

Extract folder in 7z file to your mods folder

The directory should look like this:
/user/mods/aaMFACSHOP/
/user/mods/M Guns/




Known Issues:
  No animations for fire mode selection on auto conversions


Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.



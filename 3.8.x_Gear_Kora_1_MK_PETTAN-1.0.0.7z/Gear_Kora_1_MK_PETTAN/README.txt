Gear_Kora_1_MK_PETTAN
v1.0.0

Adds to Alice LL4
The armor in parts and full package


Installation:

First install MFAC Shop module and Armor_Inserts_MFAC

Then

Extract folder in 7z file to your mods folder

The directory should look like this:

/user/mods/aaMFACSHOP/
/user/mods/Armor_Inserts_MFAC/

/user/mods/Gear_Kora_1_MK_PETTAN/

Licenses
Modified and rigged by PETTAN - CC BY NC ND 4.0

Models from BSG - Owners something something rights

Backend/mod.ts by Mighty_Condor - University of Illinois/NCSA Open Source License


Known Issues:
If the items don't render properly on the character, inspect the base pieces for the modular parts.

Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.


安装
1. 前安装我的 MFACSHOP ( https://sns.oddba.cn/97049.html )
2. 把 zip档案打开后放进你的user/mods/文件夹。
        /user/mods/Gear_Kora_1_MK_PETTAN/
去除之前把所有mod加入的物品消除。

移动系统位置移动座M已经加入黑名单，bots应该不可使用。
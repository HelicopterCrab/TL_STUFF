abMFAC_Armor_Inserts
v1.0.1




Installation:



Extract folder in 7z file to your mods folder

The directory should look like this:


/user/mods/abMFAC_Armor_Inserts/

Licenses
PETTAN - CC BY NC ND 4.0


Backend/mod.ts by Mighty_Condor - University of Illinois/NCSA Open Source License


Known Issues:
If the items don't render properly on the character, inspect the base pieces for the modular parts.

Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.


安装
1. 把 7z档案打开后放进你的user/mods/文件夹。
        /user/mods/abMFAC_Armor_Inserts/
去除之前把所有mod加入的物品消除。

移动系统位置移动座M已经加入黑名单，bots应该不可使用。
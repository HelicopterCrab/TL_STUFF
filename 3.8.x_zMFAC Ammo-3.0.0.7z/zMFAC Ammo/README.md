MFAC Ammo
v1.2.0

Epilepsy warning!! Mod adds flashing lights in the form of a flashbang round.

A mod that adds some new ammos to the game.

This mod is not balanced and won't be.


This mod wouldn't be possible without Mighty_Condor's code as the framework.




Installation:

Extract folder in 7z file to your mods folder

The directory should look like this:

/user/mods/zM AMMO/



Ammunition configs for FONTAINE'S ZEROING QUALITY OF LIFE included

To Install drop the Zeroing folder into BepInEx\plugins and overwrite ammo.json


List of Items:


    Ammo:
    (Alice 3)   Frag rounds for every caliber
    (Alice 1)   12/70(12ga) Flash
    (Alice 1)   US-BT Subsonic Rounds for multiple calibers
    (Alice 2)   SSAP Supersonic Rounds for multiple calibers
    (Alice 1)   Duplex 5.56 round
    (Alice 1)   9mm T-PX(Tracer Pyrotechnic Explosive) noisemaker round.

    Weapon parts:
    (Alice 1)   Duplex AR-15 Barrel 370mm and 20 inch

Known Issues:

    1. The ammo doesn't seem to be compatible with some weapon mods that load after it.


Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.



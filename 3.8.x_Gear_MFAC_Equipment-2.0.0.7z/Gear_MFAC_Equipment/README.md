MFAC Equipment
v2.0.0


This mod wouldn't be possible without Mighty_Condor's code as the framework.


Installation:

Extract folder in 7z file to your mods folder

The directory should look like this:
/user/mods/aaMFACSHOP/
/user/mods/Armor_Inserts_MFAC/
/user/mods/Gear_MFAC_Equipment/




Known Issues:
  ???


Uninstalling:

If you want to remove the mod make sure to not have any of the added items in your profile before deleting the folder.


